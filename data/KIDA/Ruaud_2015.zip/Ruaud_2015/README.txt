Network used in Ruaud et al. 2015, MNRAS, Volume 447, Issue 4, p.4004-4017.

The gas phase network is based on the network kida.uva.2011 with updates from Loison et al. 2012 (MNRAS, Volume 421, Issue 2, pp. 1476-1484), 
Wakelam et al. 2013 (preprint, arXiv:1310.4350) and Loison et al. 2014b (MNRAS, Volume 443, Issue 1, p.398-410). 

The grain network is based on Garrod et al. 2007 (A&A, Volume 467, Issue 3, June I 2007, pp.1103-1115) with further modifications to take into account the 
new surface mechanisms introduced in this paper.